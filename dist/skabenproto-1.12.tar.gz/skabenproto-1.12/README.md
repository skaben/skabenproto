SKABEN over MQTT

command protocol for dungeon devices

-----

PacketEncoder

.load() - dict to packet object
.encode() - packet object to mqtt message

PacketDecoder

.decode() - mqtt message to dict
